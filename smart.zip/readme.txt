
  S - Mart 
    -> The electrocins store

/* page load takes some time due to many images */

Features:
 -> login 
 -> Create Account 
 -> Feedback
 -> Cart ( but not finished )